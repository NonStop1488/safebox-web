"""
app/dependencies.py
FastAPI dependencies: авторизація, отримання поточного юзера
"""
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt

from app.security import decode_token
from app.database import get_db, dict_cursor

bearer_scheme = HTTPBearer()


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db=Depends(get_db),
) -> dict:
    """
    Dependency — декодує JWT, перевіряє юзера в БД.
    Використання: current_user = Depends(get_current_user)
    """
    credentials_exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Невалідний або прострочений токен",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decode_token(credentials.credentials)
        if payload.get("type") != "access":
            raise credentials_exc
        user_id: str = payload.get("sub")
        if not user_id:
            raise credentials_exc
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Токен прострочений",
        )
    except jwt.PyJWTError:
        raise credentials_exc

    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT id, email, is_active, two_factor_enabled FROM users WHERE id = %s",
        (user_id,),
    )
    user = cursor.fetchone()

    if not user or not user["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Користувача не знайдено або акаунт деактивовано",
        )

    return user
