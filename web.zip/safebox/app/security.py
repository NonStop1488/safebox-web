"""
app/security.py
Всі криптографічні операції SafeBox:
  - Argon2id  → хешування master password (аутентифікація)
  - PBKDF2    → генерація ключа шифрування з master password
  - AES-256-GCM → шифрування/розшифрування даних
  - JWT       → access / refresh токени
"""
import os
import base64
import secrets
import hashlib
import hmac
from datetime import datetime, timezone, timedelta
from typing import Optional

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from app.config import settings

# ─── Argon2id (хешування master password для входу) ──────────
_argon2 = PasswordHasher(
    time_cost=3,        # 3 ітерації
    memory_cost=65536,  # 64 MB
    parallelism=4,
    hash_len=32,
    salt_len=16,
)


def hash_master_password(master_password: str) -> str:
    """Хешує master password через Argon2id для зберігання в БД."""
    return _argon2.hash(master_password)


def verify_master_password(master_password: str, hashed: str) -> bool:
    """Перевіряє master password проти Argon2id хешу."""
    try:
        return _argon2.verify(hashed, master_password)
    except (VerifyMismatchError, VerificationError):
        return False


# ─── PBKDF2 (генерація ключа шифрування) ─────────────────────
KDF_ITERATIONS = 600_000  # OWASP 2024 рекомендація
KDF_KEY_LENGTH = 64       # 64 bytes = 32 (enc key) + 32 (mac key)


def generate_kdf_salt() -> bytes:
    """Генерує криптографічно безпечну 256-bit сіль для PBKDF2."""
    return secrets.token_bytes(32)


def derive_master_key(master_password: str, salt: bytes, iterations: int = KDF_ITERATIONS) -> bytes:
    """
    PBKDF2-HMAC-SHA256: перетворює master password на 512-bit ключ.
    Перші 32 байти = encryption key
    Останні 32 байти = MAC key
    ВИКОНУЄТЬСЯ ТІЛЬКИ НА КЛІЄНТІ — тут лише для тестування/демо.
    """
    key = hashlib.pbkdf2_hmac(
        hash_name="sha256",
        password=master_password.encode("utf-8"),
        salt=salt,
        iterations=iterations,
        dklen=KDF_KEY_LENGTH,
    )
    return key  # [0:32] = enc_key, [32:64] = mac_key


# ─── AES-256-GCM (шифрування/розшифрування) ──────────────────
IV_LENGTH = 12   # 96-bit IV — стандарт для GCM
TAG_LENGTH = 16  # 128-bit authentication tag


def generate_iv() -> bytes:
    """Генерує унікальний 96-bit IV. ОБОВ'ЯЗКОВО новий для кожного шифрування."""
    return secrets.token_bytes(IV_LENGTH)


def encrypt_aes256_gcm(plaintext: str, key: bytes) -> tuple[str, str, str]:
    """
    Шифрує рядок через AES-256-GCM.

    Args:
        plaintext: Текст для шифрування (рядок)
        key: 32-байтний ключ шифрування

    Returns:
        (ciphertext_b64, iv_b64, auth_tag_b64) — три Base64-рядки для збереження в БД
    """
    if len(key) != 32:
        raise ValueError("Ключ має бути 32 байти (256 bit)")

    iv = generate_iv()
    aesgcm = AESGCM(key)

    # encrypt() повертає ciphertext + auth_tag (16 байт в кінці)
    encrypted = aesgcm.encrypt(iv, plaintext.encode("utf-8"), None)

    ciphertext = encrypted[:-TAG_LENGTH]
    auth_tag   = encrypted[-TAG_LENGTH:]

    return (
        base64.b64encode(ciphertext).decode("utf-8"),
        base64.b64encode(iv).decode("utf-8"),
        base64.b64encode(auth_tag).decode("utf-8"),
    )


def decrypt_aes256_gcm(ciphertext_b64: str, iv_b64: str, auth_tag_b64: str, key: bytes) -> str:
    """
    Розшифровує AES-256-GCM дані.
    Автоматично перевіряє цілісність через auth tag.
    Кидає InvalidTag якщо дані були підроблені.
    """
    ciphertext = base64.b64decode(ciphertext_b64)
    iv         = base64.b64decode(iv_b64)
    auth_tag   = base64.b64decode(auth_tag_b64)

    aesgcm = AESGCM(key)
    # Web Crypto API повертає ciphertext + tag разом
    combined = ciphertext + auth_tag
    decrypted = aesgcm.decrypt(iv, combined, None)
    return decrypted.decode("utf-8")


def encrypt_field(value: str, key: bytes) -> dict:
    """
    Зручна обгортка: шифрує одне поле і повертає dict для збереження в БД.
    Повертає: {"encrypted": "...", "iv": "...", "auth_tag": "..."}
    """
    enc, iv, tag = encrypt_aes256_gcm(value, key)
    return {"encrypted": enc, "iv": iv, "auth_tag": tag}


def decrypt_field(field: dict, key: bytes) -> str:
    """Розшифровує поле збережене через encrypt_field()."""
    return decrypt_aes256_gcm(
        field["encrypted"],
        field["iv"],
        field["auth_tag"],
        key,
    )


# ─── Protected Symmetric Key ──────────────────────────────────
def generate_vault_key() -> bytes:
    """Генерує 32-байтний vault key для шифрування записів."""
    return secrets.token_bytes(32)


def protect_vault_key(vault_key: bytes, master_key: bytes) -> str:
    """
    Шифрує vault key через master key для збереження в БД.
    Повертає Base64-рядок у форматі: iv.ciphertext.auth_tag
    """
    enc, iv, tag = encrypt_aes256_gcm(base64.b64encode(vault_key).decode(), master_key)
    return f"{iv}.{enc}.{tag}"


def unprotect_vault_key(protected: str, master_key: bytes) -> bytes:
    """Розшифровує vault key з protected_symmetric_key."""
    parts = protected.split(".")
    if len(parts) != 3:
        raise ValueError("Невірний формат protected_symmetric_key")
    iv, enc, tag = parts
    vault_key_b64 = decrypt_aes256_gcm(enc, iv, tag, master_key)
    return base64.b64decode(vault_key_b64)


# ─── JWT ─────────────────────────────────────────────────────
def create_access_token(user_id: str, email: str) -> str:
    """Створює короткотривалий access token (30 хв)."""
    payload = {
        "sub":   user_id,
        "email": email,
        "type":  "access",
        "iat":   datetime.now(timezone.utc),
        "exp":   datetime.now(timezone.utc) + timedelta(minutes=settings.JWT_ACCESS_EXPIRE_MINUTES),
    }
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)


def create_refresh_token(user_id: str, device_id: str) -> str:
    """Створює довготривалий refresh token (30 днів)."""
    payload = {
        "sub":       user_id,
        "device_id": device_id,
        "type":      "refresh",
        "iat":       datetime.now(timezone.utc),
        "exp":       datetime.now(timezone.utc) + timedelta(days=settings.JWT_REFRESH_EXPIRE_DAYS),
    }
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)


def decode_token(token: str) -> dict:
    """Декодує і валідує JWT токен. Кидає виключення якщо невалідний."""
    return jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])


def hash_token(token: str) -> str:
    """Bcrypt-подібний хеш для зберігання refresh token у БД."""
    return hashlib.sha256(token.encode()).hexdigest()
