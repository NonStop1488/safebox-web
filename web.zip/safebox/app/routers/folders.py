"""
app/routers/folders.py
CRUD для папок:
  GET    /folders         — всі папки
  POST   /folders         — створити
  PUT    /folders/{id}    — оновити
  DELETE /folders/{id}    — видалити (soft delete)
"""
import uuid
from datetime import datetime, timezone
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Request

from app.database import get_db, dict_cursor
from app.dependencies import get_current_user
from app.schemas import FolderCreate, FolderUpdate, FolderResponse, MessageResponse

router = APIRouter(prefix="/folders", tags=["Folders"])


def _row_to_response(row: dict) -> FolderResponse:
    return FolderResponse(
        id=row["id"],
        user_id=row["user_id"],
        parent_id=row["parent_id"],
        name_encrypted=row["name_encrypted"],
        name_iv=row["name_iv"],
        name_auth_tag=row["name_auth_tag"],
        color=row["color"],
        icon=row["icon"],
        sort_order=row["sort_order"],
        is_deleted=bool(row["is_deleted"]),
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


@router.get("", response_model=List[FolderResponse])
def list_folders(current_user=Depends(get_current_user), db=Depends(get_db)):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT * FROM folders WHERE user_id = %s AND is_deleted = False ORDER BY sort_order, created_at",
        (current_user["id"],),
    )
    return [_row_to_response(r) for r in cursor.fetchall()]


@router.post("", response_model=FolderResponse, status_code=201)
def create_folder(body: FolderCreate, current_user=Depends(get_current_user), db=Depends(get_db)):
    cursor = dict_cursor(db)

    if body.parent_id:
        cursor.execute(
            "SELECT id FROM folders WHERE id = %s AND user_id = %s AND is_deleted = False",
            (body.parent_id, current_user["id"]),
        )
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Батьківську папку не знайдено")

    fid = str(uuid.uuid4())
    cursor.execute(
        """INSERT INTO folders
           (id, user_id, parent_id, name_encrypted, name_iv, name_auth_tag,
            color, icon, sort_order)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (fid, current_user["id"], body.parent_id,
         body.name_encrypted, body.name_iv, body.name_auth_tag,
         body.color, body.icon, body.sort_order),
    )
    cursor.execute("SELECT * FROM folders WHERE id = %s", (fid,))
    return _row_to_response(cursor.fetchone())


@router.put("/{folder_id}", response_model=FolderResponse)
def update_folder(
    folder_id: str,
    body: FolderUpdate,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT id FROM folders WHERE id = %s AND user_id = %s AND is_deleted = False",
        (folder_id, current_user["id"]),
    )
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Папку не знайдено")

    updates = {}
    if body.name_encrypted is not None: updates["name_encrypted"] = body.name_encrypted
    if body.name_iv        is not None: updates["name_iv"]        = body.name_iv
    if body.name_auth_tag  is not None: updates["name_auth_tag"]  = body.name_auth_tag
    if body.parent_id      is not None: updates["parent_id"]      = body.parent_id
    if body.color          is not None: updates["color"]          = body.color
    if body.icon           is not None: updates["icon"]           = body.icon
    if body.sort_order     is not None: updates["sort_order"]     = body.sort_order

    if updates:
        set_clause = ", ".join(f"{k} = %s" for k in updates)
        cursor.execute(
            f"UPDATE folders SET {set_clause} WHERE id = %s",
            list(updates.values()) + [folder_id],
        )

    cursor.execute("SELECT * FROM folders WHERE id = %s", (folder_id,))
    return _row_to_response(cursor.fetchone())


@router.delete("/{folder_id}", response_model=MessageResponse)
def delete_folder(
    folder_id: str,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT id FROM folders WHERE id = %s AND user_id = %s AND is_deleted = False",
        (folder_id, current_user["id"]),
    )
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Папку не знайдено")

    cursor.execute("UPDATE folders SET is_deleted = True WHERE id = %s", (folder_id,))
    # Паролі в цій папці залишаються (folder_id стане NULL через FK ON DELETE SET NULL)
    return MessageResponse(message="Папку видалено")
