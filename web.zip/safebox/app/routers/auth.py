"""
app/routers/auth.py
Ендпоінти аутентифікації:
  POST /auth/register        — реєстрація
  POST /auth/prelogin        — отримати KDF параметри
  POST /auth/login           — вхід → access + refresh токени (або 2FA challenge)
  POST /auth/2fa/setup       — отримати TOTP secret + QR URI (потрібен логін)
  POST /auth/2fa/enable      — підтвердити код і увімкнути 2FA
  POST /auth/2fa/verify      — верифікація TOTP при вході (якщо 2FA увімкнена)
  POST /auth/2fa/disable     — вимкнути 2FA (потрібен TOTP код)
  POST /auth/refresh         — оновити access токен
  POST /auth/logout          — вихід (відкликати пристрій)
"""
import base64
import hmac
import hashlib
import struct
import time
import uuid
import urllib.request
import urllib.parse
import secrets
import json as json_lib
from datetime import datetime, timezone, timedelta


from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import RedirectResponse

from app.database import get_db, dict_cursor
from app.dependencies import get_current_user
from app.schemas import (
    RegisterRequest, VerifyEmailRequest, PreloginRequest, PreloginResponse,
    LoginRequest, TokenResponse, RefreshRequest,
    MessageResponse,
)
from app.security import (
    hash_master_password, verify_master_password,
    generate_kdf_salt, KDF_ITERATIONS,
    generate_vault_key, protect_vault_key, derive_master_key,
    create_access_token, create_refresh_token, decode_token, hash_token,
)
import jwt as _jwt
from app.config import settings as _settings

import random
import string
from pydantic import BaseModel as PydanticModel


# ═══════════════════════════════════════════════════════════════
#  EMAIL ВЕРИФІКАЦІЯ
# ═══════════════════════════════════════════════════════════════

class SendVerificationRequest(PydanticModel):
    email: str

class VerifyEmailResponse(PydanticModel):
    message: str


def _generate_code(length: int = 6) -> str:
    """Генерує 6-значний числовий код."""
    return ''.join(random.choices(string.digits, k=length))


def _send_email(to: str, subject: str, html_body: str) -> bool:
    """Відправляє email через Resend SDK."""
    try:
        import resend
        resend.api_key = _settings.RESEND_API_KEY
        r = resend.Emails.send({
            "from": "SafeBox <noreply@safebox.lol>",
            "to": [to],
            "subject": subject,
            "html": html_body,
        })
        print(f"[EMAIL OK] id={r.get('id')} to={to}")
        return True
    except Exception as e:
        print(f"[EMAIL ERROR] {e}")
        return False

def _send_verification_email(to: str, code: str) -> bool:
    """Відправляє лист з кодом підтвердження."""
    html = f"""
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#0f1318;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr><td align="center" style="padding:40px 20px;">
      <table width="480" cellpadding="0" cellspacing="0"
             style="background:#141a22;border-radius:16px;border:1px solid rgba(255,255,255,0.08);overflow:hidden;">
        <!-- Header -->
        <tr><td style="background:#0b0e13;padding:24px 32px;border-bottom:1px solid rgba(255,255,255,0.06);">
          <table cellpadding="0" cellspacing="0"><tr>
            <td style="padding-right:10px;">
              <div style="width:36px;height:36px;background:rgba(63,224,138,0.12);border-radius:10px;
                          border:1px solid rgba(63,224,138,0.25);text-align:center;line-height:36px;font-size:18px;">🛡</div>
            </td>
            <td><span style="font-size:1.1rem;font-weight:700;color:#ffffff;letter-spacing:-0.01em;">SafeBox</span></td>
          </tr></table>
        </td></tr>
        <!-- Body -->
        <tr><td style="padding:32px;">
          <h2 style="margin:0 0 12px;font-size:1.3rem;font-weight:700;color:#dce4f0;">
            Підтвердіть вашу електронну пошту
          </h2>
          <p style="margin:0 0 24px;font-size:0.9rem;color:rgba(220,228,240,0.6);line-height:1.6;">
            Для завершення реєстрації в SafeBox введіть цей код підтвердження:
          </p>
          <!-- Code block -->
          <div style="background:#0f1318;border:1px solid rgba(63,224,138,0.25);border-radius:12px;
                      padding:24px;text-align:center;margin-bottom:24px;">
            <div style="font-size:2.5rem;font-weight:800;letter-spacing:0.35em;color:#3fe08a;
                        font-family:monospace;">{code}</div>
            <div style="font-size:0.75rem;color:rgba(220,228,240,0.35);margin-top:8px;">
              Код дійсний 15 хвилин
            </div>
          </div>
          <p style="margin:0 0 8px;font-size:0.82rem;color:rgba(220,228,240,0.4);line-height:1.6;">
            Якщо ви не реєструвались у SafeBox — просто проігноруйте цей лист.
          </p>
        </td></tr>
        <!-- Footer -->
        <tr><td style="padding:16px 32px 24px;border-top:1px solid rgba(255,255,255,0.06);">
          <p style="margin:0;font-size:0.75rem;color:rgba(220,228,240,0.25);text-align:center;">
            © 2025 SafeBox · Менеджер паролів
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""
    return _send_email(to, "SafeBox — Код підтвердження", html)


# Коди верифікації зберігаються в PostgreSQL (таблиця email_verifications)

router = APIRouter(prefix="/auth", tags=["Auth"])


# ═══════════════════════════════════════════════════════════════
#  TOTP (RFC 6238) — без зовнішніх бібліотек
# ═══════════════════════════════════════════════════════════════

def _totp_generate(secret_b32: str, digits: int = 6, period: int = 30) -> str:
    """Генерує поточний TOTP код."""
    key = base64.b32decode(secret_b32.upper().replace(' ', ''))
    counter = int(time.time()) // period
    msg = struct.pack('>Q', counter)
    h = hmac.new(key, msg, hashlib.sha1).digest()
    offset = h[-1] & 0x0F
    code = struct.unpack('>I', h[offset:offset+4])[0] & 0x7FFFFFFF
    return str(code % (10 ** digits)).zfill(digits)


def _totp_verify(secret_b32: str, code: str, window: int = 1) -> bool:
    """Перевіряє TOTP код з вікном ±window кроків (захист від drift)."""
    if not code or len(code) != 6:
        return False
    key = base64.b32decode(secret_b32.upper().replace(' ', ''))
    counter = int(time.time()) // 30
    for delta in range(-window, window + 1):
        msg = struct.pack('>Q', counter + delta)
        h = hmac.new(key, msg, hashlib.sha1).digest()
        offset = h[-1] & 0x0F
        expected = struct.unpack('>I', h[offset:offset+4])[0] & 0x7FFFFFFF
        expected = str(expected % 1_000_000).zfill(6)
        if hmac.compare_digest(expected, code.strip()):
            return True
    return False


def _totp_new_secret() -> str:
    """Генерує новий Base32 секрет (160 біт)."""
    raw = secrets.token_bytes(20)
    return base64.b32encode(raw).decode()


def _totp_uri(secret: str, email: str, issuer: str = "SafeBox") -> str:
    """Генерує otpauth:// URI для QR-коду."""
    params = urllib.parse.urlencode({
        'secret': secret,
        'issuer': issuer,
        'algorithm': 'SHA1',
        'digits': 6,
        'period': 30,
    })
    label = urllib.parse.quote(f"{issuer}:{email}")
    return f"otpauth://totp/{label}?{params}"


def _qr_url(uri: str) -> str:
    """Генерує URL до QR-коду через Google Charts API."""
    encoded = urllib.parse.quote(uri)
    return f"https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={encoded}"


# ═══════════════════════════════════════════════════════════════
#  Допоміжні
# ═══════════════════════════════════════════════════════════════

def _audit(db, user_id, action, request: Request, device_id=None, metadata=None):
    cursor = db.cursor()
    cursor.execute(
        """INSERT INTO audit_log (id, user_id, device_id, action, ip_address, user_agent, metadata)
           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
        (
            str(uuid.uuid4()), user_id, device_id, action,
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
            str(metadata) if metadata else None,
        ),
    )


# ═══════════════════════════════════════════════════════════════
#  Pydantic моделі для 2FA
# ═══════════════════════════════════════════════════════════════

class TotpVerifyRequest(PydanticModel):
    totp_code: str
    # При вході — передається temp_token отриманий після логіну
    temp_token: str | None = None

class TotpDisableRequest(PydanticModel):
    totp_code: str

class TotpSetupResponse(PydanticModel):
    secret: str
    uri: str
    qr_url: str

class LoginResponse2FA(PydanticModel):
    requires_2fa: bool = True
    temp_token: str       # короткоживучий токен для /auth/2fa/verify


# ═══════════════════════════════════════════════════════════════
#  REGISTER
# ═══════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════
#  SEND VERIFICATION CODE
# ═══════════════════════════════════════════════════════════════

@router.post("/send-verification", response_model=MessageResponse)
def send_verification(body: SendVerificationRequest, db=Depends(get_db)):
    """Перевіряє email і відправляє код підтвердження."""
    email = body.email.strip().lower()
    cursor = dict_cursor(db)

    # Перевірити чи не зайнятий email
    cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
    if cursor.fetchone():
        raise HTTPException(status_code=400, detail="Цей email вже зареєстровано")

    # Створити таблицю якщо не існує
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS email_verifications (
            email      TEXT PRIMARY KEY,
            code       TEXT NOT NULL,
            expires_at TIMESTAMPTZ NOT NULL,
            attempts   INTEGER NOT NULL DEFAULT 1
        )
    """)

    # Rate limit — не більше 3 запитів за 15 хвилин
    cursor.execute(
        "SELECT attempts, expires_at FROM email_verifications WHERE email = %s",
        (email,)
    )
    existing = cursor.fetchone()
    if existing and existing["attempts"] >= 3:
        if datetime.now(timezone.utc) < existing["expires_at"]:
            raise HTTPException(status_code=429, detail="Забагато спроб. Спробуйте через 15 хвилин.")

    # Генерувати код
    code = _generate_code(6)
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=15)
    attempts = (existing["attempts"] + 1) if existing else 1

    cursor.execute("""
        INSERT INTO email_verifications (email, code, expires_at, attempts)
        VALUES (%s, %s, %s, %s)
        ON CONFLICT (email) DO UPDATE
            SET code = EXCLUDED.code,
                expires_at = EXCLUDED.expires_at,
                attempts = EXCLUDED.attempts
    """, (email, code, expires_at, attempts))

    # Відправити email
    ok = _send_verification_email(email, code)
    if not ok:
        raise HTTPException(status_code=500, detail="Не вдалося відправити email. Перевірте адресу.")

    return MessageResponse(message=f"Код підтвердження відправлено на {email}")


# ═══════════════════════════════════════════════════════════════
#  REGISTER WITH EMAIL VERIFICATION
# ═══════════════════════════════════════════════════════════════

@router.post("/verify-and-register", response_model=TokenResponse, status_code=201)
def verify_and_register(body: VerifyEmailRequest, request: Request, db=Depends(get_db)):
    """Перевіряє код і реєструє користувача."""
    email = body.email.strip().lower()

    # Перевірити код в БД
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT code, expires_at FROM email_verifications WHERE email = %s",
        (email,)
    )
    stored = cursor.fetchone()
    if not stored:
        raise HTTPException(status_code=400, detail="Спочатку запросіть код підтвердження")

    if datetime.now(timezone.utc) > stored["expires_at"]:
        cursor.execute("DELETE FROM email_verifications WHERE email = %s", (email,))
        raise HTTPException(status_code=400, detail="Код підтвердження прострочений. Запросіть новий.")

    if stored["code"] != body.code.strip():
        raise HTTPException(status_code=400, detail="Невірний код підтвердження")

    # Код правильний — видалити з БД
    cursor.execute("DELETE FROM email_verifications WHERE email = %s", (email,))

    # Перевірити чи не зайнятий email (race condition)
    cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
    if cursor.fetchone():
        raise HTTPException(status_code=400, detail="Цей email вже зареєстровано")

    # ── ZK: сервер ніколи не бачить master_password у відкритому вигляді ──
    # Клієнт вже виконав PBKDF2, згенерував vault_key і зашифрував його.
    # Сервер тільки зберігає:
    #   - password_hash  (SHA-256 хеш від master_password для Argon2 верифікації)
    #   - kdf_salt, kdf_iterations  (параметри PBKDF2 для відновлення master_key на клієнті)
    #   - protected_symmetric_key  (vault_key зашифрований master_key'ом)
    user_id  = str(uuid.uuid4())
    pw_hash  = hash_master_password(body.password_hash)
    kdf_salt_bytes = base64.b64decode(body.kdf_salt)

    cursor.execute(
        """INSERT INTO users
           (id, email, master_password_hash, kdf_salt, kdf_iterations,
            protected_symmetric_key, email_verified)
           VALUES (%s, %s, %s, %s, %s, %s, True)""",
        (user_id, email, pw_hash, kdf_salt_bytes, body.kdf_iterations,
         body.protected_symmetric_key),
    )

    device_id = str(uuid.uuid4())
    cursor.execute(
        """INSERT INTO devices
           (id, user_id, device_name, device_type, trust_level, ip_address, user_agent, is_active)
           VALUES (%s, %s, %s, %s, 'trusted', %s, %s, True)""",
        (
            device_id, user_id, body.device_name, body.device_type,
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
        ),
    )

    access_token  = create_access_token(user_id, email)
    refresh_token = create_refresh_token(user_id, device_id)

    cursor.execute(
        "UPDATE devices SET session_token_hash = %s WHERE id = %s",
        (hash_token(refresh_token), device_id),
    )

    _audit(db, user_id, "REGISTER", request, device_id)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        protected_symmetric_key=body.protected_symmetric_key,
        kdf_salt=body.kdf_salt,
        kdf_iterations=body.kdf_iterations,
    )


@router.post("/register", response_model=TokenResponse, status_code=201)
def register(body: RegisterRequest, request: Request, db=Depends(get_db)):
    cursor = dict_cursor(db)

    cursor.execute("SELECT id FROM users WHERE email = %s", (body.email,))
    if cursor.fetchone():
        raise HTTPException(status_code=400, detail="Email вже зареєстровано")

    # ZK: хешуємо password_hash який вже прийшов від клієнта
    user_id  = str(uuid.uuid4())
    pw_hash  = hash_master_password(body.password_hash)
    kdf_salt_bytes = base64.b64decode(body.kdf_salt)

    cursor.execute(
        """INSERT INTO users
           (id, email, master_password_hash, kdf_salt, kdf_iterations,
            protected_symmetric_key, email_verified)
           VALUES (%s, %s, %s, %s, %s, %s, False)""",
        (user_id, body.email, pw_hash, kdf_salt_bytes,
         body.kdf_iterations, body.protected_symmetric_key),
    )

    device_id = str(uuid.uuid4())
    cursor.execute(
        """INSERT INTO devices
           (id, user_id, device_name, device_type, trust_level, ip_address, user_agent, is_active)
           VALUES (%s, %s, %s, %s, 'trusted', %s, %s, True)""",
        (
            device_id, user_id, body.device_name, body.device_type.value,
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
        ),
    )

    access_token  = create_access_token(user_id, body.email)
    refresh_token = create_refresh_token(user_id, device_id)

    cursor.execute(
        "UPDATE devices SET session_token_hash = %s WHERE id = %s",
        (hash_token(refresh_token), device_id),
    )

    _audit(db, user_id, "REGISTER", request, device_id)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        protected_symmetric_key=body.protected_symmetric_key,
        kdf_salt=body.kdf_salt,
        kdf_iterations=body.kdf_iterations,
    )


# ═══════════════════════════════════════════════════════════════
#  PRELOGIN
# ═══════════════════════════════════════════════════════════════

@router.post("/prelogin", response_model=PreloginResponse)
def prelogin(body: PreloginRequest, db=Depends(get_db)):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT kdf_salt, kdf_iterations, kdf_algorithm FROM users WHERE email = %s AND is_active = True",
        (body.email,),
    )
    user = cursor.fetchone()

    if not user:
        return PreloginResponse(
            kdf_salt=base64.b64encode(generate_kdf_salt()).decode(),
            kdf_iterations=KDF_ITERATIONS,
            kdf_algorithm="PBKDF2",
        )

    return PreloginResponse(
        kdf_salt=base64.b64encode(bytes(user["kdf_salt"])).decode(),
        kdf_iterations=user["kdf_iterations"],
        kdf_algorithm=user["kdf_algorithm"],
    )


# ═══════════════════════════════════════════════════════════════
#  LOGIN  (з підтримкою 2FA)
# ═══════════════════════════════════════════════════════════════

@router.post("/login")
def login(body: LoginRequest, request: Request, db=Depends(get_db)):
    cursor = dict_cursor(db)
    cursor.execute(
        """SELECT id, email, master_password_hash, kdf_salt,
                  kdf_iterations, protected_symmetric_key, is_active,
                  two_factor_enabled,
                  COALESCE(totp_secret, two_factor_secret) AS totp_secret
           FROM users WHERE email = %s""",
        (body.email,),
    )
    user = cursor.fetchone()

    if not user:
        raise HTTPException(status_code=401, detail="Невірний email або пароль")

    if not user["is_active"]:
        raise HTTPException(status_code=403, detail="Акаунт деактивовано")

    if not verify_master_password(body.password_hash, user["master_password_hash"]):
        _audit(db, user["id"], "LOGIN_FAILED", request)
        raise HTTPException(status_code=401, detail="Невірний email або пароль")

    if not user["protected_symmetric_key"]:
        raise HTTPException(
            status_code=500,
            detail="protected_symmetric_key відсутній у БД. Акаунт пошкоджений — зверніться до підтримки."
        )

    # ── Якщо 2FA увімкнена — видати тимчасовий токен ──────────
    if user["two_factor_enabled"] and user["totp_secret"]:
        # Тимчасовий токен: зашифровуємо user_id + device_info
        temp_payload = {
            "sub":         user["id"],
            "email":       user["email"],
            "type":        "2fa_pending",
            "device_name": body.device_name,
            "device_type": body.device_type.value,
            "psk":         user["protected_symmetric_key"],
            "kdf_salt":    base64.b64encode(bytes(user["kdf_salt"])).decode(),
            "kdf_iter":    user["kdf_iterations"],
        }
        # Використовуємо access_token але з коротким типом
        from datetime import timedelta
        temp_token = _jwt.encode(
            {
                "sub":      user["id"],
                "email":    user["email"],
                "type":     "2fa_pending",
                "2fa_data": temp_payload,
                "iat":      datetime.now(timezone.utc),
                "exp":      datetime.now(timezone.utc) + timedelta(minutes=10),
            },
            _settings.JWT_SECRET,
            algorithm=_settings.JWT_ALGORITHM,
        )
        _audit(db, user["id"], "LOGIN_2FA_REQUIRED", request)
        # Повертаємо 202 з флагом
        from fastapi.responses import JSONResponse
        return JSONResponse(
            status_code=202,
            content={"requires_2fa": True, "temp_token": temp_token}
        )

    # ── Звичайний логін (без 2FA) ──────────────────────────────
    device_id = str(uuid.uuid4())
    cursor.execute(
        """INSERT INTO devices
           (id, user_id, device_name, device_type, trust_level, ip_address, user_agent, is_active)
           VALUES (%s, %s, %s, %s, 'trusted', %s, %s, True)""",
        (
            device_id, user["id"], body.device_name, body.device_type.value,
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
        ),
    )

    access_token  = create_access_token(user["id"], user["email"])
    refresh_token = create_refresh_token(user["id"], device_id)

    cursor.execute(
        "UPDATE devices SET session_token_hash = %s WHERE id = %s",
        (hash_token(refresh_token), device_id),
    )
    cursor.execute(
        "UPDATE users SET last_login_at = %s WHERE id = %s",
        (datetime.now(timezone.utc), user["id"]),
    )

    _audit(db, user["id"], "LOGIN_SUCCESS", request, device_id)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        protected_symmetric_key=user["protected_symmetric_key"],
        kdf_salt=base64.b64encode(bytes(user["kdf_salt"])).decode(),
        kdf_iterations=user["kdf_iterations"],
    )


# ═══════════════════════════════════════════════════════════════
#  2FA — SETUP (отримати QR і secret)
# ═══════════════════════════════════════════════════════════════

@router.post("/2fa/setup", response_model=TotpSetupResponse)
def totp_setup(
    request: Request,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    """Повертає новий TOTP secret і QR-код. Не вмикає 2FA до підтвердження."""
    cursor = dict_cursor(db)
    cursor.execute("SELECT email, two_factor_enabled FROM users WHERE id = %s", (current_user["id"],))
    user = cursor.fetchone()

    if user["two_factor_enabled"]:
        raise HTTPException(status_code=400, detail="2FA вже увімкнена. Спочатку вимкніть.")

    secret = _totp_new_secret()
    uri    = _totp_uri(secret, user["email"])
    qr     = _qr_url(uri)

    # Тимчасово зберігаємо secret (не активований) — пишемо в обидві колонки для сумісності
    cursor.execute(
        "UPDATE users SET totp_secret = %s, two_factor_secret = %s WHERE id = %s",
        (secret, secret, current_user["id"]),
    )
    _audit(db, current_user["id"], "2FA_SETUP_STARTED", request)

    return TotpSetupResponse(secret=secret, uri=uri, qr_url=qr)


# ═══════════════════════════════════════════════════════════════
#  2FA — ENABLE (підтвердити код і активувати)
# ═══════════════════════════════════════════════════════════════

@router.post("/2fa/enable", response_model=MessageResponse)
def totp_enable(
    body: TotpVerifyRequest,
    request: Request,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT COALESCE(totp_secret, two_factor_secret) AS totp_secret, two_factor_enabled FROM users WHERE id = %s",
        (current_user["id"],),
    )
    user = cursor.fetchone()

    if user["two_factor_enabled"]:
        raise HTTPException(status_code=400, detail="2FA вже активована")

    if not user["totp_secret"]:
        raise HTTPException(status_code=400, detail="Спочатку запустіть налаштування 2FA")

    if not _totp_verify(user["totp_secret"], body.totp_code):
        raise HTTPException(status_code=400, detail="Невірний код. Перевірте час на пристрої.")

    cursor.execute(
        "UPDATE users SET two_factor_enabled = True WHERE id = %s",
        (current_user["id"],),
    )
    _audit(db, current_user["id"], "2FA_ENABLED", request)

    return MessageResponse(message="Двофакторна автентифікація увімкнена")


# ═══════════════════════════════════════════════════════════════
#  2FA — VERIFY (при вході)
# ═══════════════════════════════════════════════════════════════

@router.post("/2fa/verify", response_model=TokenResponse)
def totp_verify_login(
    body: TotpVerifyRequest,
    request: Request,
    db=Depends(get_db),
):
    """Перевіряє TOTP код після логіну і видає повні токени."""
    if not body.temp_token:
        raise HTTPException(status_code=400, detail="temp_token обов'язковий")

    try:
        payload = decode_token(body.temp_token)
    except Exception:
        raise HTTPException(status_code=401, detail="Невалідний або прострочений токен")

    if payload.get("type") != "2fa_pending":
        raise HTTPException(status_code=401, detail="Невалідний тип токена")

    user_id = payload.get("sub")
    data    = payload.get("2fa_data", {})
    if not user_id:
        raise HTTPException(status_code=401, detail="Невалідний токен")

    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT id, email, COALESCE(totp_secret, two_factor_secret) AS totp_secret, two_factor_enabled, is_active FROM users WHERE id = %s",
        (user_id,),
    )
    user = cursor.fetchone()

    if not user or not user["is_active"]:
        raise HTTPException(status_code=401, detail="Користувача не знайдено")

    if not _totp_verify(user["totp_secret"], body.totp_code):
        _audit(db, user_id, "2FA_FAILED", request)
        raise HTTPException(status_code=400, detail="Невірний код автентифікатора")

    # Видати повні токени
    device_type = data.get("device_type", "web")
    device_name = data.get("device_name", "Unknown")

    device_id = str(uuid.uuid4())
    cursor.execute(
        """INSERT INTO devices
           (id, user_id, device_name, device_type, trust_level, ip_address, user_agent, is_active)
           VALUES (%s, %s, %s, %s, 'trusted', %s, %s, True)""",
        (
            device_id, user_id, device_name, device_type,
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
        ),
    )

    access_token  = create_access_token(user_id, user["email"])
    refresh_token = create_refresh_token(user_id, device_id)

    cursor.execute(
        "UPDATE devices SET session_token_hash = %s WHERE id = %s",
        (hash_token(refresh_token), device_id),
    )
    cursor.execute(
        "UPDATE users SET last_login_at = %s WHERE id = %s",
        (datetime.now(timezone.utc), user_id),
    )

    _audit(db, user_id, "LOGIN_2FA_SUCCESS", request, device_id)

    psk      = data.get("psk", "")
    kdf_salt = data.get("kdf_salt", "")
    kdf_iter = data.get("kdf_iter", KDF_ITERATIONS)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        protected_symmetric_key=psk,
        kdf_salt=kdf_salt,
        kdf_iterations=kdf_iter,
    )


# ═══════════════════════════════════════════════════════════════
#  2FA — DISABLE
# ═══════════════════════════════════════════════════════════════

@router.post("/2fa/disable", response_model=MessageResponse)
def totp_disable(
    body: TotpDisableRequest,
    request: Request,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT COALESCE(totp_secret, two_factor_secret) AS totp_secret, two_factor_enabled FROM users WHERE id = %s",
        (current_user["id"],),
    )
    user = cursor.fetchone()

    if not user["two_factor_enabled"]:
        raise HTTPException(status_code=400, detail="2FA не увімкнена")

    if not _totp_verify(user["totp_secret"], body.totp_code):
        raise HTTPException(status_code=400, detail="Невірний код автентифікатора")

    cursor.execute(
        "UPDATE users SET two_factor_enabled = False, totp_secret = NULL, two_factor_secret = NULL WHERE id = %s",
        (current_user["id"],),
    )
    _audit(db, current_user["id"], "2FA_DISABLED", request)

    return MessageResponse(message="Двофакторна автентифікація вимкнена")


# ═══════════════════════════════════════════════════════════════
#  2FA — STATUS
# ═══════════════════════════════════════════════════════════════

@router.get("/2fa/status")
def totp_status(
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT two_factor_enabled FROM users WHERE id = %s",
        (current_user["id"],),
    )
    user = cursor.fetchone()
    return {"two_factor_enabled": bool(user["two_factor_enabled"])}


# ═══════════════════════════════════════════════════════════════
#  REFRESH
# ═══════════════════════════════════════════════════════════════

@router.post("/refresh", response_model=TokenResponse)
def refresh_token(body: RefreshRequest, db=Depends(get_db)):
    try:
        payload = decode_token(body.refresh_token)
    except Exception:
        raise HTTPException(status_code=401, detail="Невалідний refresh токен")

    if payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Невалідний тип токена")

    device_id = payload.get("device_id")
    user_id   = payload.get("sub")

    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT * FROM devices WHERE id = %s AND user_id = %s AND is_active = True",
        (device_id, user_id),
    )
    device = cursor.fetchone()

    if not device or device["session_token_hash"] != hash_token(body.refresh_token):
        raise HTTPException(status_code=401, detail="Refresh токен відкликано")

    cursor.execute("SELECT id, email FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()

    new_access  = create_access_token(user["id"], user["email"])
    new_refresh = create_refresh_token(user["id"], device_id)

    cursor.execute(
        "UPDATE devices SET session_token_hash = %s WHERE id = %s",
        (hash_token(new_refresh), device_id),
    )

    cursor.execute(
        "SELECT kdf_salt, kdf_iterations, protected_symmetric_key FROM users WHERE id = %s",
        (user_id,),
    )
    u = cursor.fetchone()

    return TokenResponse(
        access_token=new_access,
        refresh_token=new_refresh,
        protected_symmetric_key=u["protected_symmetric_key"],
        kdf_salt=base64.b64encode(bytes(u["kdf_salt"])).decode(),
        kdf_iterations=u["kdf_iterations"],
    )


# ═══════════════════════════════════════════════════════════════
#  GOOGLE AUTH
# ═══════════════════════════════════════════════════════════════

GOOGLE_CLIENT_ID = "260458731697-b5mh8ek1kkm23bmplaflbn1di1kfv2uf.apps.googleusercontent.com"


class GoogleLoginRequest(PydanticModel):
    credential: str


class GoogleTokenRequest(PydanticModel):
    id_token: str  # id_token від нативного Google Sign-In


def _google_finish(user, body_device_name, body_device_type, request, db, cursor):
    """Спільна логіка видачі токенів після Google логіну."""
    device_id = str(uuid.uuid4())
    cursor.execute(
        """INSERT INTO devices
           (id, user_id, device_name, device_type, trust_level, ip_address, user_agent, is_active)
           VALUES (%s, %s, %s, %s, 'trusted', %s, %s, True)""",
        (
            device_id, user["id"],
            body_device_name or "Google OAuth",
            body_device_type or "web",
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
        ),
    )
    access_token  = create_access_token(user["id"], user["email"])
    refresh_token = create_refresh_token(user["id"], device_id)
    cursor.execute(
        "UPDATE devices SET session_token_hash = %s WHERE id = %s",
        (hash_token(refresh_token), device_id),
    )
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        protected_symmetric_key=user["protected_symmetric_key"],
        kdf_salt=base64.b64encode(bytes(user["kdf_salt"])).decode(),
        kdf_iterations=user["kdf_iterations"],
    )


@router.post("/google-token")
def google_token_login(body: GoogleTokenRequest, request: Request, db=Depends(get_db)):
    # Верифікуємо id_token через Google API
    try:
        url = f"https://oauth2.googleapis.com/tokeninfo?id_token={body.id_token}"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as resp:
            token_info = json_lib.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        raise HTTPException(status_code=400, detail="Недійсний Google токен")
    except Exception:
        raise HTTPException(status_code=400, detail="Помилка верифікації Google токену")

    if token_info.get("aud") != GOOGLE_CLIENT_ID:
        raise HTTPException(status_code=400, detail="Токен видано для іншого додатку")

    email          = token_info.get("email", "")
    email_verified = token_info.get("email_verified") == "true"

    if not email_verified:
        raise HTTPException(status_code=400, detail="Email не підтверджений у Google")
    if not email:
        raise HTTPException(status_code=400, detail="Email відсутній у токені")

    cursor = dict_cursor(db)
    cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
    user = cursor.fetchone()

    if not user:
        # ── Google OAuth + ZK ─────────────────────────────────────────
        # Генеруємо випадковий vault_key на сервері ТІЛЬКИ для Google-акаунтів
        # (немає master_password → неможливо зробити повний ZK).
        # vault_key повертається клієнту один раз і зберігається в sessionStorage.
        # Сервер зберігає його у вигляді protected_symmetric_key = base64(vault_key).
        user_id   = str(uuid.uuid4())
        vault_key = secrets.token_bytes(32)
        protected = base64.b64encode(vault_key).decode()
        placeholder_hash = hash_master_password(secrets.token_urlsafe(32))
        placeholder_salt = base64.b64encode(secrets.token_bytes(32)).decode()
        cursor.execute(
            """INSERT INTO users
               (id, email, master_password_hash, kdf_salt, kdf_iterations,
                protected_symmetric_key, email_verified, is_active)
               VALUES (%s,%s,%s,%s,%s,%s,True,True)""",
            (user_id, email, placeholder_hash, base64.b64decode(placeholder_salt),
             KDF_ITERATIONS, protected),
        )
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        _audit(db, user_id, "REGISTER_GOOGLE", request)
    else:
        if not user["is_active"]:
            raise HTTPException(status_code=403, detail="Акаунт деактивовано")

        # Якщо PSK містить крапки — це пароль-акаунт (формат iv.cipher.tag).
        # Google-вхід не може розшифрувати такий ключ без master password.
        psk = user["protected_symmetric_key"] or ""
        if "." in psk:
            raise HTTPException(
                status_code=409,
                detail="Цей email вже зареєстровано з паролем. Увійдіть через форму входу.",
            )

        cursor.execute("UPDATE users SET last_login_at = %s WHERE id = %s",
                       (datetime.now(timezone.utc), user["id"]))
        _audit(db, user["id"], "LOGIN_GOOGLE", request)

    return _google_finish(user, "Google OAuth", "web", request, db, cursor)


@router.post("/google")
def google_login(body: GoogleLoginRequest, request: Request, db=Depends(get_db)):
    try:
        url = f"https://oauth2.googleapis.com/tokeninfo?id_token={body.credential}"
        with urllib.request.urlopen(url, timeout=10) as resp:
            token_info = json_lib.loads(resp.read().decode())
    except Exception:
        raise HTTPException(status_code=401, detail="Невалідний Google токен")

    if token_info.get("aud") != GOOGLE_CLIENT_ID:
        raise HTTPException(status_code=401, detail="Токен виданий для іншого додатку")

    email = token_info.get("email")
    if not email:
        raise HTTPException(status_code=400, detail="Email не знайдено в Google токені")
    if not token_info.get("email_verified", False):
        raise HTTPException(status_code=400, detail="Email не підтверджений у Google")

    cursor = dict_cursor(db)
    cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
    user = cursor.fetchone()

    if not user:
        # Google OAuth + ZK: vault_key генерується сервером, повертається клієнту один раз
        user_id   = str(uuid.uuid4())
        vault_key = secrets.token_bytes(32)
        protected = base64.b64encode(vault_key).decode()
        placeholder_hash = hash_master_password(secrets.token_urlsafe(32))
        placeholder_salt = base64.b64encode(secrets.token_bytes(32)).decode()
        cursor.execute(
            """INSERT INTO users
               (id, email, master_password_hash, kdf_salt, kdf_iterations,
                protected_symmetric_key, email_verified, is_active)
               VALUES (%s, %s, %s, %s, %s, %s, True, True)""",
            (user_id, email, placeholder_hash, base64.b64decode(placeholder_salt),
             KDF_ITERATIONS, protected),
        )
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        _audit(db, user_id, "REGISTER_GOOGLE", request)
    else:
        if not user["is_active"]:
            raise HTTPException(status_code=403, detail="Акаунт деактивовано")

        psk = user["protected_symmetric_key"] or ""
        if "." in psk:
            raise HTTPException(
                status_code=409,
                detail="Цей email вже зареєстровано з паролем. Увійдіть через форму входу.",
            )

        cursor.execute(
            "UPDATE users SET last_login_at = %s WHERE id = %s",
            (datetime.now(timezone.utc), user["id"]),
        )
        _audit(db, user["id"], "LOGIN_GOOGLE", request)

    return _google_finish(user, "Google OAuth", "web", request, db, cursor)


# ═══════════════════════════════════════════════════════════════
#  GOOGLE MOBILE CALLBACK (PKCE flow для Android)
# ═══════════════════════════════════════════════════════════════

GOOGLE_CLIENT_SECRET = _settings.GOOGLE_CLIENT_SECRET


@router.get("/google/mobile-callback")
def google_mobile_callback(code: str, state: str):
    """
    Google редиректить сюди після авторизації.
    Використовуємо intent:// схему щоб Chrome Custom Tab коректно
    передав deep link в Android замість обробки всередині себе.
    """
    # intent:// гарантує що Chrome Custom Tab запустить Android Intent
    # і передасть керування застосунку через onNewIntent
    intent_url = (
        f"intent://oauth?code={code}&state={state}"
        f"#Intent;scheme=safebox;package=com.safebox.app;end"
    )
    return RedirectResponse(
        url=intent_url,
        status_code=302,
    )


class GooglePkceExchangeRequest(PydanticModel):
    code:          str
    code_verifier: str
    redirect_uri:  str


@router.post("/google/pkce-exchange")
def google_pkce_exchange(body: GooglePkceExchangeRequest, request: Request, db=Depends(get_db)):
    """
    Приймає code + code_verifier від мобільного клієнта,
    обмінює їх на Google токени, дістає профіль і логінить/реєструє юзера.
    """
    # 1. Обміняти code на access_token
    token_data = urllib.parse.urlencode({
        "code":          body.code,
        "client_id":     GOOGLE_CLIENT_ID,
        "client_secret": GOOGLE_CLIENT_SECRET,
        "redirect_uri":  body.redirect_uri,
        "grant_type":    "authorization_code",
        "code_verifier": body.code_verifier,
    }).encode()

    try:
        req = urllib.request.Request(
            "https://oauth2.googleapis.com/token",
            data=token_data,
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            token_info = json_lib.loads(resp.read().decode())
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Не вдалося отримати Google токен: {e}")

    if "error" in token_info:
        raise HTTPException(status_code=401, detail=f"Google помилка: {token_info['error']}")

    access_token_google = token_info.get("access_token")
    if not access_token_google:
        raise HTTPException(status_code=401, detail="Google не повернув access_token")

    # 2. Отримати профіль користувача
    try:
        profile_req = urllib.request.Request(
            "https://www.googleapis.com/oauth2/v2/userinfo",
            headers={"Authorization": f"Bearer {access_token_google}"},
        )
        with urllib.request.urlopen(profile_req, timeout=10) as resp:
            profile = json_lib.loads(resp.read().decode())
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Не вдалося отримати профіль Google: {e}")

    email = profile.get("email")
    if not email:
        raise HTTPException(status_code=400, detail="Email не знайдено в Google профілі")
    if not profile.get("verified_email", False):
        raise HTTPException(status_code=400, detail="Email не підтверджений у Google")

    # 3. Логін або реєстрація (та сама логіка що і в /auth/google)
    cursor = dict_cursor(db)
    cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
    user = cursor.fetchone()

    if not user:
        user_id   = str(uuid.uuid4())
        vault_key = secrets.token_bytes(32)
        protected = base64.b64encode(vault_key).decode()
        placeholder_hash = hash_master_password(secrets.token_urlsafe(32))
        placeholder_salt = base64.b64encode(secrets.token_bytes(32)).decode()
        cursor.execute(
            """INSERT INTO users
               (id, email, master_password_hash, kdf_salt, kdf_iterations,
                protected_symmetric_key, email_verified, is_active)
               VALUES (%s,%s,%s,%s,%s,%s,True,True)""",
            (user_id, email, placeholder_hash, base64.b64decode(placeholder_salt),
             KDF_ITERATIONS, protected),
        )
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        _audit(db, user_id, "REGISTER_GOOGLE", request)
    else:
        if not user["is_active"]:
            raise HTTPException(status_code=403, detail="Акаунт деактивовано")

        psk = user["protected_symmetric_key"] or ""
        if "." in psk:
            raise HTTPException(
                status_code=409,
                detail="Цей email вже зареєстровано з паролем. Увійдіть через форму входу.",
            )

        cursor.execute(
            "UPDATE users SET last_login_at = %s WHERE id = %s",
            (datetime.now(timezone.utc), user["id"]),
        )
        _audit(db, user["id"], "LOGIN_GOOGLE", request)

    return _google_finish(user, "Google OAuth Mobile", "mobile", request, db, cursor)


# ═══════════════════════════════════════════════════════════════
#  LOGOUT
# ═══════════════════════════════════════════════════════════════

@router.post("/logout", response_model=MessageResponse)
def logout(body: RefreshRequest, request: Request, db=Depends(get_db)):
    try:
        payload   = decode_token(body.refresh_token)
        device_id = payload.get("device_id")
        user_id   = payload.get("sub")

        cursor = db.cursor()
        cursor.execute(
            "UPDATE devices SET session_token_hash = NULL, is_active = False WHERE id = %s",
            (device_id,),
        )
        _audit(db, user_id, "SESSION_REVOKED", request, device_id)
    except Exception:
        pass

    return MessageResponse(message="Вихід виконано успішно")
