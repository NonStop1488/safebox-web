"""
app/routers/passwords.py
CRUD для записів паролів:
  GET    /passwords          — всі паролі поточного юзера
  POST   /passwords          — створити запис
  GET    /passwords/{id}     — отримати один запис
  PUT    /passwords/{id}     — оновити запис
  DELETE /passwords/{id}     — видалити (soft delete)
  GET    /passwords/sync     — дельта-синхронізація
"""
import uuid
from datetime import datetime, timezone
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from app.database import get_db, dict_cursor
from app.dependencies import get_current_user
from app.schemas import (
    PasswordCreate, PasswordUpdate, PasswordResponse,
    SyncResponse, MessageResponse,
)

router = APIRouter(prefix="/passwords", tags=["Passwords"])


def _row_to_response(row: dict) -> PasswordResponse:
    return PasswordResponse(
        id=row["id"],
        user_id=row["user_id"],
        folder_id=row["folder_id"],
        type=row["type"],
        name_encrypted=row["name_encrypted"],
        name_iv=row["name_iv"],
        name_auth_tag=row["name_auth_tag"],
        data_encrypted=row["data_encrypted"],
        data_iv=row["data_iv"],
        auth_tag=row["auth_tag"],
        key_version=row["key_version"],
        is_pinned=bool(row["is_pinned"]),
        is_favorite=bool(row["is_favorite"]),
        is_deleted=bool(row["is_deleted"]),
        password_changed_at=row["password_changed_at"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


# ─── GET /passwords ───────────────────────────────────────────
@router.get("", response_model=List[PasswordResponse])
def list_passwords(
    folder_id: Optional[str] = Query(None),
    type:       Optional[str] = Query(None),
    pinned:     Optional[bool] = Query(None),
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    """Повертає всі активні (не видалені) паролі поточного юзера."""
    cursor = dict_cursor(db)

    sql = "SELECT * FROM passwords WHERE user_id = %s AND is_deleted = False"
    params = [current_user["id"]]

    if folder_id:
        sql += " AND folder_id = %s"
        params.append(folder_id)
    if type:
        sql += " AND type = %s"
        params.append(type)
    if pinned is not None:
        sql += " AND is_pinned = %s"
        params.append(True if pinned else False)

    sql += " ORDER BY is_pinned DESC, updated_at DESC"
    cursor.execute(sql, params)
    rows = cursor.fetchall()
    return [_row_to_response(r) for r in rows]


# ─── POST /passwords ──────────────────────────────────────────
@router.post("", response_model=PasswordResponse, status_code=201)
def create_password(
    body: PasswordCreate,
    request: Request,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)

    # Перевірити що folder_id належить цьому юзеру
    if body.folder_id:
        cursor.execute(
            "SELECT id FROM folders WHERE id = %s AND user_id = %s AND is_deleted = False",
            (body.folder_id, current_user["id"]),
        )
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Папку не знайдено")

    pw_id = str(uuid.uuid4())
    now   = datetime.now(timezone.utc)

    cursor.execute(
        """INSERT INTO passwords
           (id, user_id, folder_id, type,
            name_encrypted, name_iv, name_auth_tag,
            data_encrypted, data_iv, auth_tag,
            key_version, is_pinned, is_favorite, password_changed_at)
           VALUES (%s,%s,%s,%s, %s,%s,%s, %s,%s,%s, %s,%s,%s,%s)""",
        (
            pw_id, current_user["id"], body.folder_id, body.type.value,
            body.name_encrypted, body.name_iv, body.name_auth_tag,
            body.data_encrypted, body.data_iv, body.auth_tag,
            body.key_version, body.is_pinned, body.is_favorite, now,
        ),
    )

    # Аудит
    cursor.execute(
        """INSERT INTO audit_log (id, user_id, action, target_id, target_type, ip_address)
           VALUES (%s,%s,'PASSWORD_CREATED',%s,'password',%s)""",
        (str(uuid.uuid4()), current_user["id"], pw_id,
         request.client.host if request.client else None),
    )

    cursor.execute("SELECT * FROM passwords WHERE id = %s", (pw_id,))
    return _row_to_response(cursor.fetchone())


# ─── GET /passwords/{id} ──────────────────────────────────────
@router.get("/{pw_id}", response_model=PasswordResponse)
def get_password(
    pw_id: str,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT * FROM passwords WHERE id = %s AND user_id = %s AND is_deleted = False",
        (pw_id, current_user["id"]),
    )
    row = cursor.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Запис не знайдено")
    return _row_to_response(row)


# ─── PUT /passwords/{id} ──────────────────────────────────────
@router.put("/{pw_id}", response_model=PasswordResponse)
def update_password(
    pw_id: str,
    body: PasswordUpdate,
    request: Request,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT * FROM passwords WHERE id = %s AND user_id = %s AND is_deleted = False",
        (pw_id, current_user["id"]),
    )
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Запис не знайдено")

    # Динамічно будуємо UPDATE тільки з переданих полів
    updates = {}
    if body.folder_id      is not None: updates["folder_id"]       = body.folder_id
    if body.name_encrypted is not None: updates["name_encrypted"]  = body.name_encrypted
    if body.name_iv        is not None: updates["name_iv"]         = body.name_iv
    if body.name_auth_tag  is not None: updates["name_auth_tag"]   = body.name_auth_tag
    if body.data_encrypted is not None:
        updates["data_encrypted"]  = body.data_encrypted
        updates["password_changed_at"] = datetime.now(timezone.utc)
    if body.data_iv        is not None: updates["data_iv"]         = body.data_iv
    if body.auth_tag       is not None: updates["auth_tag"]        = body.auth_tag
    if body.key_version    is not None: updates["key_version"]     = body.key_version
    if body.is_pinned      is not None: updates["is_pinned"]       = body.is_pinned
    if body.is_favorite    is not None: updates["is_favorite"]     = body.is_favorite

    if not updates:
        cursor.execute("SELECT * FROM passwords WHERE id = %s", (pw_id,))
        return _row_to_response(cursor.fetchone())

    set_clause = ", ".join(f"{k} = %s" for k in updates)
    values = list(updates.values()) + [pw_id]
    cursor.execute(f"UPDATE passwords SET {set_clause} WHERE id = %s", values)

    cursor.execute(
        """INSERT INTO audit_log (id, user_id, action, target_id, target_type, ip_address)
           VALUES (%s,%s,'PASSWORD_UPDATED',%s,'password',%s)""",
        (str(uuid.uuid4()), current_user["id"], pw_id,
         request.client.host if request.client else None),
    )

    cursor.execute("SELECT * FROM passwords WHERE id = %s", (pw_id,))
    return _row_to_response(cursor.fetchone())


# ─── DELETE /passwords/{id} ───────────────────────────────────
@router.delete("/{pw_id}", response_model=MessageResponse)
def delete_password(
    pw_id: str,
    request: Request,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT id FROM passwords WHERE id = %s AND user_id = %s AND is_deleted = False",
        (pw_id, current_user["id"]),
    )
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Запис не знайдено")

    # Soft delete — не видаляємо фізично (потрібно для синхронізації)
    cursor.execute(
        "UPDATE passwords SET is_deleted = True WHERE id = %s",
        (pw_id,),
    )
    cursor.execute(
        """INSERT INTO audit_log (id, user_id, action, target_id, target_type, ip_address)
           VALUES (%s,%s,'PASSWORD_DELETED',%s,'password',%s)""",
        (str(uuid.uuid4()), current_user["id"], pw_id,
         request.client.host if request.client else None),
    )
    return MessageResponse(message="Запис видалено")


# ─── GET /passwords/sync?since=<datetime> ─────────────────────
@router.get("/sync/delta", response_model=SyncResponse)
def sync_passwords(
    since: Optional[datetime] = Query(None, description="ISO datetime останньої синхронізації"),
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    """
    Дельта-синхронізація: повертає всі записи змінені після `since`.
    Включає soft-deleted (is_deleted=1) щоб клієнт міг їх видалити локально.
    """
    cursor = dict_cursor(db)
    uid = current_user["id"]

    if since:
        cursor.execute(
            "SELECT * FROM passwords WHERE user_id = %s AND updated_at > %s ORDER BY updated_at",
            (uid, since),
        )
        pws = cursor.fetchall()
        cursor.execute(
            "SELECT * FROM folders WHERE user_id = %s AND updated_at > %s ORDER BY updated_at",
            (uid, since),
        )
        folders = cursor.fetchall()
    else:
        cursor.execute(
            "SELECT * FROM passwords WHERE user_id = %s ORDER BY updated_at",
            (uid,),
        )
        pws = cursor.fetchall()
        cursor.execute(
            "SELECT * FROM folders WHERE user_id = %s ORDER BY updated_at",
            (uid,),
        )
        folders = cursor.fetchall()

    from app.routers.folders import _row_to_response as folder_row
    return SyncResponse(
        passwords=[_row_to_response(r) for r in pws],
        folders=[folder_row(r) for r in folders],
        sync_time=datetime.now(timezone.utc),
    )
