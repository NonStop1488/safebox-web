"""
app/routers/users.py
Профіль користувача та пристрої:
  GET    /users/me              — профіль
  GET    /users/me/devices      — список пристроїв
  DELETE /users/me/devices/{id} — відкликати пристрій
  GET    /users/me/audit        — журнал активності
"""
import uuid
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from app.database import get_db, dict_cursor
from app.dependencies import get_current_user
from app.schemas import UserResponse, DeviceResponse, MessageResponse

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("/me", response_model=UserResponse)
def get_profile(current_user=Depends(get_current_user), db=Depends(get_db)):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT id, email, two_factor_enabled, email_verified, created_at, last_login_at FROM users WHERE id = %s",
        (current_user["id"],),
    )
    return cursor.fetchone()


@router.get("/me/devices", response_model=List[DeviceResponse])
def list_devices(current_user=Depends(get_current_user), db=Depends(get_db)):
    cursor = dict_cursor(db)
    cursor.execute(
        """SELECT id, device_name, device_type, trust_level,
                  last_sync_at, ip_address, is_active, created_at
           FROM devices
           WHERE user_id = %s AND is_active = True
           ORDER BY created_at DESC""",
        (current_user["id"],),
    )
    return cursor.fetchall()


@router.delete("/me/devices/{device_id}", response_model=MessageResponse)
def revoke_device(
    device_id: str,
    request: Request,
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        "SELECT id FROM devices WHERE id = %s AND user_id = %s",
        (device_id, current_user["id"]),
    )
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Пристрій не знайдено")

    cursor.execute(
        "UPDATE devices SET is_active = False, session_token_hash = NULL WHERE id = %s",
        (device_id,),
    )
    cursor.execute(
        """INSERT INTO audit_log (id, user_id, action, target_id, target_type, ip_address)
           VALUES (%s,%s,'DEVICE_REVOKED',%s,'device',%s)""",
        (str(uuid.uuid4()), current_user["id"], device_id,
         request.client.host if request.client else None),
    )
    return MessageResponse(message="Доступ пристрою відкликано")


@router.get("/me/audit")
def get_audit_log(
    limit:  int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    current_user=Depends(get_current_user),
    db=Depends(get_db),
):
    cursor = dict_cursor(db)
    cursor.execute(
        """SELECT action, target_type, ip_address, created_at, metadata
           FROM audit_log
           WHERE user_id = %s
           ORDER BY created_at DESC
           LIMIT %s OFFSET %s""",
        (current_user["id"], limit, offset),
    )
    return cursor.fetchall()
