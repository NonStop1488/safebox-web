"""
app/database.py — PostgreSQL через psycopg2
"""
import psycopg2
import psycopg2.extras
from psycopg2 import pool as pg_pool
from app.config import settings


def _build_dsn() -> str:
    """Будує рядок підключення до PostgreSQL."""
    if settings.DATABASE_URL:
        # Render дає postgres:// але psycopg2 потребує postgresql://
        url = settings.DATABASE_URL
        if url.startswith("postgres://"):
            url = "postgresql://" + url[len("postgres://"):]
        return url
    return (
        f"postgresql://{settings.DB_USER}:{settings.DB_PASSWORD}"
        f"@{settings.DB_HOST}:{settings.DB_PORT}/{settings.DB_NAME}"
    )


# Connection pool
_pool = pg_pool.ThreadedConnectionPool(
    minconn=1,
    maxconn=10,
    dsn=_build_dsn(),
)


def get_db():
    """
    FastAPI dependency — повертає з'єднання з пулу.
    Автоматично закриває після запиту.
    """
    conn = _pool.getconn()
    conn.autocommit = False
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        _pool.putconn(conn)


def dict_cursor(conn):
    """Повертає курсор що повертає рядки як dict."""
    return conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
