"""
app/main.py — SafeBox API для Render (PostgreSQL)
"""
import os
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse

from app.config import settings
from app.routers import auth, passwords, folders, users

_is_production = settings.APP_ENV == "production"

# Swagger / ReDoc вимкнені у продакшні — не розкриваємо API-схему
app = FastAPI(
    title="SafeBox API",
    description="Zero-Knowledge Password Manager Backend",
    version="1.0.0",
    docs_url=None if _is_production else "/docs",
    redoc_url=None if _is_production else "/redoc",
    openapi_url=None if _is_production else "/openapi.json",
)

# CORS — тільки конкретний Vercel-домен у продакшні.
# Задай ALLOWED_ORIGIN=https://your-app.vercel.app у Render → Environment Variables.
_allowed_origins: list[str] = []
# https://localhost — origin Capacitor WebView (androidScheme: 'https')
# crypto.subtle вимагає HTTPS або localhost — тому використовуємо https scheme
_capacitor_origins = [
    "https://localhost",
    "capacitor://localhost",
    "capacitor://",
]

if _is_production:
    _allowed_origins = _capacitor_origins[:]
    if settings.ALLOWED_ORIGIN:
        _allowed_origins.append(settings.ALLOWED_ORIGIN)
else:
    _allowed_origins = [
        "http://localhost:3000",
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:8080",
    ] + _capacitor_origins
    if settings.ALLOWED_ORIGIN:
        _allowed_origins.append(settings.ALLOWED_ORIGIN)

_cors_origin = settings.ALLOWED_ORIGIN if _is_production else "*"

app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins if _is_production else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    origin = request.headers.get("origin", "")
    cors_header = origin if origin in _allowed_origins else (
        _allowed_origins[0] if _allowed_origins else ""
    )
    return JSONResponse(
        status_code=500,
        content={"detail": "Внутрішня помилка сервера"},
        headers={
            "Access-Control-Allow-Origin": cors_header or "*",
            "Access-Control-Allow-Credentials": "true",
        },
    )


app.include_router(auth.router,      prefix="/api/v1")
app.include_router(passwords.router, prefix="/api/v1")
app.include_router(folders.router,   prefix="/api/v1")
app.include_router(users.router,     prefix="/api/v1")


@app.get("/health", tags=["System"])
def health():
    return {"status": "ok", "service": "SafeBox API", "version": "1.0.0"}


@app.get("/", tags=["System"])
def root():
    docs_hint = "disabled in production" if _is_production else "/docs"
    return {"message": "SafeBox API", "docs": docs_hint, "health": "/health"}


# Fallback: Google Console може мати зареєстрований старий URL без /api/v1.
# Цей маршрут приймає редирект від Google і одразу перенаправляє назад у додаток.
@app.get("/auth/google/mobile-callback", tags=["System"])
def google_mobile_callback_compat(code: str = "", state: str = "", error: str = ""):
    if error:
        return RedirectResponse(url=f"safebox://oauth?error={error}", status_code=302)
    return RedirectResponse(
        url=f"safebox://oauth?code={code}&state={state}",
        status_code=302,
    )
