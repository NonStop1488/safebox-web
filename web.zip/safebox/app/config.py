"""
app/config.py — підтримка PostgreSQL для Render
"""
import sys
from pydantic import BaseSettings, validator
from typing import Optional

_INSECURE_DEFAULTS = {"change-me", "secret", "changeme", "password", "jwt_secret"}


class Settings(BaseSettings):
    # PostgreSQL (Render дає DATABASE_URL автоматично)
    DATABASE_URL: Optional[str] = None

    # Fallback окремі параметри (для локальної розробки)
    DB_HOST: str = "localhost"
    DB_PORT: int = 5432
    DB_NAME: str = "safebox"
    DB_USER: str = "postgres"
    DB_PASSWORD: str = ""

    # JWT — ОБОВ'ЯЗКОВО задати у Render → Environment Variables
    JWT_SECRET: str = "change-me"
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_EXPIRE_MINUTES: int = 30
    JWT_REFRESH_EXPIRE_DAYS: int = 30

    # App
    APP_ENV: str = "development"
    APP_HOST: str = "0.0.0.0"
    APP_PORT: int = 8000

    # CORS — задай реальний Vercel-домен у Render → Environment Variables
    # Приклад: ALLOWED_ORIGIN=https://your-app.vercel.app
    ALLOWED_ORIGIN: str = ""

    # Email (Resend API)
    RESEND_API_KEY: str = ""

    # Google OAuth
    GOOGLE_CLIENT_SECRET: str = ""

    @validator("JWT_SECRET")
    def jwt_secret_must_be_secure(cls, v):
        if v.lower() in _INSECURE_DEFAULTS or len(v) < 32:
            if True:  # перевіряємо завжди, але блокуємо тільки у продакшні
                pass  # validation відбудеться нижче при старті
        return v

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()

# Захист від запуску з небезпечними налаштуваннями у продакшні
if settings.APP_ENV == "production":
    if settings.JWT_SECRET.lower() in _INSECURE_DEFAULTS or len(settings.JWT_SECRET) < 32:
        print(
            "КРИТИЧНА ПОМИЛКА: JWT_SECRET не задано або небезпечне значення.\n"
            "Встанови змінну середовища JWT_SECRET у Render → Environment Variables.\n"
            "Мінімальна довжина: 32 символи. Генерація: python -c \"import secrets; print(secrets.token_hex(32))\"",
            file=sys.stderr,
        )
        sys.exit(1)
