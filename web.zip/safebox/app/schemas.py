"""
app/schemas.py
Pydantic моделі для валідації запитів і відповідей API
"""
from __future__ import annotations
from datetime import datetime
from typing import Optional, List
from enum import Enum

from pydantic import BaseModel, EmailStr, Field, validator


# ─── Enums ───────────────────────────────────────────────────
class PasswordType(str, Enum):
    login    = "login"
    note     = "note"
    card     = "card"
    identity = "identity"


class DeviceType(str, Enum):
    web      = "web"
    windows  = "windows"
    android  = "android"
    ios      = "ios"
    cli      = "cli"


# ─── Auth ────────────────────────────────────────────────────
class RegisterRequest(BaseModel):
    email:                   EmailStr
    # ZK: клієнт передає хеш пароля, а не відкритий пароль
    password_hash:           str = Field(min_length=1, max_length=256)
    # KDF параметри (генеруються на клієнті)
    kdf_salt:                str   # Base64
    kdf_iterations:          int   = 600000
    # Vault key зашифрований master_key'ом (генерується на клієнті)
    protected_symmetric_key: str
    device_name:             str  = Field(default="Web Browser", max_length=200)
    device_type:             DeviceType = DeviceType.web


class VerifyEmailRequest(BaseModel):
    """Крок 2 реєстрації: підтвердження email + ZK дані від клієнта."""
    email:                   EmailStr
    code:                    str
    password_hash:           str
    kdf_salt:                str
    kdf_iterations:          int = 600000
    protected_symmetric_key: str
    device_name:             str = Field(default="Web Browser", max_length=200)
    device_type:             DeviceType = DeviceType.web


class PreloginRequest(BaseModel):
    """Крок 1 входу: клієнт запитує KDF параметри для генерації ключа."""
    email: EmailStr


class PreloginResponse(BaseModel):
    kdf_salt:       str   # Base64
    kdf_iterations: int
    kdf_algorithm:  str


class LoginRequest(BaseModel):
    email:          EmailStr
    # ZK: клієнт передає SHA-256 хеш пароля, а не відкритий пароль
    password_hash:  str
    device_name:    str = Field(default="Web Browser", max_length=200)
    device_type:    DeviceType = DeviceType.web


class TokenResponse(BaseModel):
    access_token:            str
    refresh_token:           str
    token_type:              str = "bearer"
    protected_symmetric_key: str   # зашифрований vault key для клієнта
    kdf_salt:                str
    kdf_iterations:          int


class RefreshRequest(BaseModel):
    refresh_token: str


# ─── User ────────────────────────────────────────────────────
class UserResponse(BaseModel):
    id:                      str
    email:                   str
    two_factor_enabled:      bool
    email_verified:          bool
    created_at:              datetime
    last_login_at:           Optional[datetime]


class ChangePasswordRequest(BaseModel):
    current_master_password: str
    new_master_password:     str = Field(min_length=8)
    # Клієнт перешифровує vault key новим master key і передає нову версію
    new_protected_symmetric_key: str


# ─── Folders ─────────────────────────────────────────────────
class FolderCreate(BaseModel):
    # Клієнт передає вже зашифровані дані
    name_encrypted: str
    name_iv:        str
    name_auth_tag:  str
    parent_id:      Optional[str] = None
    color:          Optional[str] = Field(default=None)
    icon:           Optional[str] = Field(default=None, max_length=64)
    sort_order:     int = 0


class FolderUpdate(BaseModel):
    name_encrypted: Optional[str] = None
    name_iv:        Optional[str] = None
    name_auth_tag:  Optional[str] = None
    parent_id:      Optional[str] = None
    color:          Optional[str] = None
    icon:           Optional[str] = None
    sort_order:     Optional[int] = None


class FolderResponse(BaseModel):
    id:             str
    user_id:        str
    parent_id:      Optional[str]
    name_encrypted: str
    name_iv:        str
    name_auth_tag:  str
    color:          Optional[str]
    icon:           Optional[str]
    sort_order:     int
    is_deleted:     bool
    created_at:     datetime
    updated_at:     datetime


# ─── Passwords ───────────────────────────────────────────────
class PasswordCreate(BaseModel):
    folder_id:           Optional[str] = None
    type:                PasswordType  = PasswordType.login
    # Зашифрована назва
    name_encrypted:      str
    name_iv:             str
    name_auth_tag:       str
    # Зашифровані дані (JSON з username, password, url, notes тощо)
    data_encrypted:      str
    data_iv:             str
    auth_tag:            str
    key_version:         int = 1
    is_pinned:           bool = False
    is_favorite:         bool = False


class PasswordUpdate(BaseModel):
    folder_id:           Optional[str]  = None
    name_encrypted:      Optional[str]  = None
    name_iv:             Optional[str]  = None
    name_auth_tag:       Optional[str]  = None
    data_encrypted:      Optional[str]  = None
    data_iv:             Optional[str]  = None
    auth_tag:            Optional[str]  = None
    key_version:         Optional[int]  = None
    is_pinned:           Optional[bool] = None
    is_favorite:         Optional[bool] = None


class PasswordResponse(BaseModel):
    id:                  str
    user_id:             str
    folder_id:           Optional[str]
    type:                str
    name_encrypted:      str
    name_iv:             str
    name_auth_tag:       str
    data_encrypted:      str
    data_iv:             str
    auth_tag:            str
    key_version:         int
    is_pinned:           bool
    is_favorite:         bool
    is_deleted:          bool
    password_changed_at: Optional[datetime]
    created_at:          datetime
    updated_at:          datetime


# ─── Sync ────────────────────────────────────────────────────
class SyncResponse(BaseModel):
    passwords: List[PasswordResponse]
    folders:   List[FolderResponse]
    sync_time: datetime


# ─── Devices ─────────────────────────────────────────────────
class DeviceResponse(BaseModel):
    id:           str
    device_name:  str
    device_type:  str
    trust_level:  str
    last_sync_at: Optional[datetime]
    ip_address:   Optional[str]
    is_active:    bool
    created_at:   datetime


# ─── Generic ─────────────────────────────────────────────────
class MessageResponse(BaseModel):
    message: str


class ErrorResponse(BaseModel):
    detail: str
