-- SafeBox PostgreSQL Schema
-- Запусти це в Render PostgreSQL після створення бази

-- Розширення для UUID
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── USERS ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id                      VARCHAR(36) PRIMARY KEY,
    email                   VARCHAR(255) UNIQUE NOT NULL,
    master_password_hash    TEXT NOT NULL,
    kdf_salt                BYTEA NOT NULL,
    kdf_iterations          INTEGER NOT NULL DEFAULT 600000,
    kdf_algorithm           VARCHAR(20) NOT NULL DEFAULT 'PBKDF2',
    protected_symmetric_key TEXT NOT NULL,
    public_key              TEXT,
    private_key_encrypted   TEXT,
    two_factor_secret       VARCHAR(64),
    two_factor_enabled      BOOLEAN NOT NULL DEFAULT FALSE,
    email_verified          BOOLEAN NOT NULL DEFAULT FALSE,
    is_active               BOOLEAN NOT NULL DEFAULT TRUE,
    last_login_at           TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- ─── FOLDERS ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS folders (
    id              VARCHAR(36) PRIMARY KEY,
    user_id         VARCHAR(36) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    parent_id       VARCHAR(36) REFERENCES folders(id) ON DELETE SET NULL,
    name_encrypted  TEXT NOT NULL,
    name_iv         TEXT NOT NULL,
    name_auth_tag   TEXT NOT NULL,
    color           VARCHAR(7),
    icon            VARCHAR(64),
    sort_order      INTEGER NOT NULL DEFAULT 0,
    is_deleted      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_folders_user ON folders(user_id);

-- ─── PASSWORDS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS passwords (
    id                  VARCHAR(36) PRIMARY KEY,
    user_id             VARCHAR(36) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    folder_id           VARCHAR(36) REFERENCES folders(id) ON DELETE SET NULL,
    type                VARCHAR(20) NOT NULL DEFAULT 'login',
    name_encrypted      TEXT NOT NULL,
    name_iv             TEXT NOT NULL,
    name_auth_tag       TEXT NOT NULL,
    data_encrypted      TEXT NOT NULL,
    data_iv             TEXT NOT NULL,
    auth_tag            TEXT NOT NULL,
    key_version         INTEGER NOT NULL DEFAULT 1,
    is_pinned           BOOLEAN NOT NULL DEFAULT FALSE,
    is_favorite         BOOLEAN NOT NULL DEFAULT FALSE,
    is_deleted          BOOLEAN NOT NULL DEFAULT FALSE,
    password_changed_at TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_passwords_user ON passwords(user_id);
CREATE INDEX IF NOT EXISTS idx_passwords_updated ON passwords(user_id, updated_at);

-- ─── DEVICES ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS devices (
    id                  VARCHAR(36) PRIMARY KEY,
    user_id             VARCHAR(36) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_name         VARCHAR(200) NOT NULL DEFAULT 'Unknown Device',
    device_type         VARCHAR(20) NOT NULL DEFAULT 'web',
    push_token          TEXT,
    last_sync_at        TIMESTAMPTZ,
    trust_level         VARCHAR(20) NOT NULL DEFAULT 'trusted',
    session_token_hash  TEXT,
    ip_address          VARCHAR(45),
    user_agent          TEXT,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_devices_user ON devices(user_id);

-- ─── AUDIT LOG ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    id          VARCHAR(36) PRIMARY KEY,
    user_id     VARCHAR(36) REFERENCES users(id) ON DELETE SET NULL,
    device_id   VARCHAR(36),
    action      VARCHAR(100) NOT NULL,
    target_id   VARCHAR(36),
    target_type VARCHAR(50),
    ip_address  VARCHAR(45),
    user_agent  TEXT,
    metadata    TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id, created_at DESC);

-- ─── AUTO-UPDATE updated_at ──────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated     BEFORE UPDATE ON users     FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_folders_updated   BEFORE UPDATE ON folders   FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_passwords_updated BEFORE UPDATE ON passwords FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_devices_updated   BEFORE UPDATE ON devices   FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── МІГРАЦІЯ: виправлення назви колонки для 2FA ─────────────
-- Проблема: auth.py використовує totp_secret, але схема має two_factor_secret
-- Рішення: додаємо totp_secret як alias (або застосовуй якщо колонки ще немає)
--
-- ВАРІАНТ A: якщо база вже існує — запусти тільки цей ALTER:
DO $$
BEGIN
    -- Додаємо totp_secret якщо її немає (для старих баз де була тільки two_factor_secret)
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='users' AND column_name='totp_secret'
    ) THEN
        ALTER TABLE users ADD COLUMN totp_secret VARCHAR(64);
        -- Копіюємо існуючі дані зі старої колонки
        UPDATE users SET totp_secret = two_factor_secret WHERE two_factor_secret IS NOT NULL;
        RAISE NOTICE 'Колонку totp_secret додано і дані скопійовано з two_factor_secret';
    END IF;
END $$;
